const fs = require('fs');
const path = require('path');

const files = [
  path.join(__dirname, '../asil-logistics/public/air.html'),
  path.join(__dirname, '../asil-logistics/public/sea.html'),
  path.join(__dirname, '../asil-logistics/public/subscription.html'),
  path.join(__dirname, '../asil-logistics/public/distribution.html'),
  path.join(__dirname, '../asil-logistics/public/maintenance.html'),
  path.join(__dirname, '../asil-logistics/public/transport.html'),
  path.join(__dirname, '../asil-logistics/public/onboarding.html')
];

for (const f of files) {
  if (!fs.existsSync(f)) continue;
  let content = fs.readFileSync(f, 'utf8');
  const original = content;
  content = content.replace(/\s*placeholder="[^"]*"/g, '');
  content = content.replace(/\s*placeholder='[^']*'/g, '');
  if (content !== original) {
    fs.writeFileSync(f, content, 'utf8');
    console.log('Cleaned placeholders in:', f);
  }
}
